import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, subscriptionsTable, usersTable, notificationsTable } from "@workspace/db";
import { getUserId } from "../lib/auth";
import { PLANS, getTokenLimit, TOKENS_PER_ROUND } from "../lib/plans";

const router: IRouter = Router();

router.get("/subscriptions/plans", async (_req, res): Promise<void> => {
  res.json(PLANS);
});

router.get("/subscriptions/current", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  let [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.userId, userId));
  if (!sub) {
    [sub] = await db.insert(subscriptionsTable).values({ userId, planId: "free" }).returning();
  }
  const endDate = new Date();
  endDate.setDate(endDate.getDate() + 30);
  res.json({ ...sub, currentPeriodEnd: sub.currentPeriodEnd?.toISOString() || endDate.toISOString() });
});

router.post("/subscriptions/upgrade", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { planId } = req.body;
  const plan = PLANS.find((p) => p.id === planId);
  if (!plan) { res.status(400).json({ error: "Invalid plan" }); return; }
  const endDate = new Date();
  endDate.setMonth(endDate.getMonth() + 1);
  let [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.userId, userId));
  if (sub) {
    [sub] = await db.update(subscriptionsTable).set({ planId, status: "active", tokensUsed: 0, currentPeriodEnd: endDate }).where(eq(subscriptionsTable.userId, userId)).returning();
  } else {
    [sub] = await db.insert(subscriptionsTable).values({ userId, planId, currentPeriodEnd: endDate }).returning();
  }
  await db.update(usersTable).set({ tier: planId }).where(eq(usersTable.id, userId));

  // Success notification
  await db.insert(notificationsTable).values({
    userId,
    type: "subscription_upgrade",
    title: `Upgraded to ${plan.name}!`,
    message: `Your subscription to ${plan.name} is now active. You have ${plan.tokenLimit?.toLocaleString()} tokens available (~${Math.floor((plan.tokenLimit || 0) / TOKENS_PER_ROUND)} scans). New engines and features unlocked!`,
    priority: "medium",
  });

  res.json({
    ...sub,
    currentPeriodEnd: sub.currentPeriodEnd?.toISOString(),
    message: `Successfully upgraded to ${plan.name}! ${plan.tokenLimit?.toLocaleString()} tokens are now available.`,
    plan,
  });
});

router.get("/subscriptions/tokens", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  let [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.userId, userId));
  if (!sub) {
    [sub] = await db.insert(subscriptionsTable).values({ userId, planId: "free" }).returning();
  }
  const tokenLimit = getTokenLimit(sub.planId);
  const tokensUsed = sub.tokensUsed;
  const tokensRemaining = Math.max(0, tokenLimit - tokensUsed);
  const isExhausted = tokensUsed >= tokenLimit;
  const warningThreshold = Math.floor(tokenLimit * 0.2);
  const isNearLimit = !isExhausted && tokensRemaining <= warningThreshold;
  const resetAt = sub.currentPeriodEnd?.toISOString() ?? null;
  res.json({ userId, planId: sub.planId, tokenLimit, tokensUsed, tokensRemaining, resetAt, warningThreshold, isExhausted, isNearLimit });
});

router.post("/subscriptions/tokens/consume", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { amount } = req.body;
  const tokens = parseInt(amount ?? TOKENS_PER_ROUND, 10);
  let [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.userId, userId));
  if (!sub) { [sub] = await db.insert(subscriptionsTable).values({ userId }).returning(); }
  const tokenLimit = getTokenLimit(sub.planId);
  if (sub.tokensUsed + tokens > tokenLimit) {
    res.status(402).json({ error: "Token limit exceeded. Upgrade your plan to continue." }); return;
  }
  [sub] = await db.update(subscriptionsTable).set({ tokensUsed: sub.tokensUsed + tokens }).where(eq(subscriptionsTable.userId, userId)).returning();
  const tokensRemaining = Math.max(0, tokenLimit - sub.tokensUsed);
  const isExhausted = sub.tokensUsed >= tokenLimit;
  const warningThreshold = Math.floor(tokenLimit * 0.2);
  const isNearLimit = !isExhausted && tokensRemaining <= warningThreshold;
  res.json({ userId, planId: sub.planId, tokenLimit, tokensUsed: sub.tokensUsed, tokensRemaining, resetAt: sub.currentPeriodEnd?.toISOString() ?? null, warningThreshold, isExhausted, isNearLimit });
});

export default router;
