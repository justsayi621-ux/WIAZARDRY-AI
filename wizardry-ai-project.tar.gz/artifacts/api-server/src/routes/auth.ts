import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, subscriptionsTable, settingsTable, notificationsTable } from "@workspace/db";
import { getUserId } from "../lib/auth";

const router: IRouter = Router();

function makeSessionToken(userId: number): string {
  return `wai_sess_${userId}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}

function makeTotpSecret(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  return Array.from({ length: 32 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

// POST /auth/check-email
router.post("/auth/check-email", async (req, res): Promise<void> => {
  const { email } = req.body;
  if (!email) { res.status(400).json({ error: "Email is required" }); return; }
  const [user] = await db
    .select({ id: usersTable.id, authMethod: usersTable.authMethod, googleId: usersTable.googleId, displayName: usersTable.displayName, deletedAt: usersTable.deletedAt })
    .from(usersTable)
    .where(eq(usersTable.email, email));
  if (!user || user.deletedAt) {
    res.json({ exists: false });
    return;
  }
  res.json({ exists: true, authMethod: user.authMethod, hasGoogle: !!user.googleId, displayName: user.displayName });
});

// POST /auth/google/signin — Google OAuth (mock)
router.post("/auth/google/signin", async (req, res): Promise<void> => {
  const { googleId, email, displayName, avatarUrl } = req.body;
  if (!googleId || !email) { res.status(400).json({ error: "googleId and email are required" }); return; }

  // Check existing by googleId
  const [byGoogle] = await db.select().from(usersTable).where(eq(usersTable.googleId, googleId));
  if (byGoogle && !byGoogle.deletedAt) {
    const token = makeSessionToken(byGoogle.id);
    await db.update(usersTable).set({ sessionToken: token, avatarUrl: avatarUrl || byGoogle.avatarUrl }).where(eq(usersTable.id, byGoogle.id));
    res.json({
      userId: byGoogle.id,
      sessionToken: token,
      needsPasswordSetup: byGoogle.needsPasswordSetup,
      isNew: false,
      displayName: byGoogle.displayName || byGoogle.username,
      message: `Welcome back to Wizardry AI, ${byGoogle.displayName || byGoogle.username}!`,
    });
    return;
  }

  // Check existing by email — merge Google into it
  const [byEmail] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (byEmail && !byEmail.deletedAt) {
    const token = makeSessionToken(byEmail.id);
    await db.update(usersTable).set({ googleId, authMethod: "google", sessionToken: token, avatarUrl: avatarUrl || byEmail.avatarUrl }).where(eq(usersTable.id, byEmail.id));
    res.json({
      userId: byEmail.id,
      sessionToken: token,
      needsPasswordSetup: !byEmail.password,
      isNew: false,
      displayName: byEmail.displayName || byEmail.username,
      message: `Welcome back to Wizardry AI, ${byEmail.displayName || byEmail.username}!`,
    });
    return;
  }

  // New Google user
  const username = email.split("@")[0].replace(/[^a-z0-9_]/gi, "_").slice(0, 18) + "_" + Math.floor(Math.random() * 999);
  const [user] = await db.insert(usersTable).values({
    email,
    username,
    displayName: displayName || username,
    avatarUrl,
    googleId,
    authMethod: "google",
    needsPasswordSetup: true,
    sessionToken: "placeholder",
  }).returning();
  const token = makeSessionToken(user.id);
  await db.update(usersTable).set({ sessionToken: token }).where(eq(usersTable.id, user.id));
  await db.insert(subscriptionsTable).values({ userId: user.id, planId: "free" });
  await db.insert(settingsTable).values({ userId: user.id });
  await db.insert(notificationsTable).values({
    userId: user.id, type: "greeting", priority: "medium",
    title: "Welcome to Wizardry AI",
    message: `Your account is ready, ${user.displayName}! Start your first scan. Don't forget to set a password for future sign-ins.`,
  });
  res.status(201).json({
    userId: user.id, sessionToken: token, needsPasswordSetup: true, isNew: true,
    displayName: user.displayName,
    message: `Account created! Welcome to Wizardry AI, ${user.displayName}!`,
  });
});

// POST /auth/apple/signin — Apple Sign-In (mock)
router.post("/auth/apple/signin", async (req, res): Promise<void> => {
  const { appleId, email, displayName } = req.body;
  if (!appleId || !email) { res.status(400).json({ error: "appleId and email are required" }); return; }
  const [byApple] = await db.select().from(usersTable).where(eq(usersTable.appleId, appleId));
  if (byApple && !byApple.deletedAt) {
    const token = makeSessionToken(byApple.id);
    await db.update(usersTable).set({ sessionToken: token }).where(eq(usersTable.id, byApple.id));
    res.json({ userId: byApple.id, sessionToken: token, needsPasswordSetup: byApple.needsPasswordSetup, isNew: false, displayName: byApple.displayName, message: `Welcome back, ${byApple.displayName}!` });
    return;
  }
  const [byEmail] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (byEmail && !byEmail.deletedAt) {
    const token = makeSessionToken(byEmail.id);
    await db.update(usersTable).set({ appleId, authMethod: "apple", sessionToken: token }).where(eq(usersTable.id, byEmail.id));
    res.json({ userId: byEmail.id, sessionToken: token, needsPasswordSetup: !byEmail.password, isNew: false, displayName: byEmail.displayName, message: `Welcome back, ${byEmail.displayName}!` });
    return;
  }
  const username = email.split("@")[0].replace(/[^a-z0-9_]/gi, "_").slice(0, 18) + "_" + Math.floor(Math.random() * 999);
  const [user] = await db.insert(usersTable).values({ email, username, displayName: displayName || username, appleId, authMethod: "apple", needsPasswordSetup: true, sessionToken: "placeholder" }).returning();
  const token = makeSessionToken(user.id);
  await db.update(usersTable).set({ sessionToken: token }).where(eq(usersTable.id, user.id));
  await db.insert(subscriptionsTable).values({ userId: user.id, planId: "free" });
  await db.insert(settingsTable).values({ userId: user.id });
  res.status(201).json({ userId: user.id, sessionToken: token, needsPasswordSetup: true, isNew: true, displayName: user.displayName, message: `Account created! Welcome to Wizardry AI, ${user.displayName}!` });
});

// POST /auth/logout
router.post("/auth/logout", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (userId) {
    await db.update(usersTable).set({ sessionToken: null }).where(eq(usersTable.id, userId));
  }
  res.json({ success: true });
});

// POST /auth/update-password
router.post("/auth/update-password", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { password, currentPassword } = req.body;
  if (!password || password.length < 8) { res.status(400).json({ error: "Password must be at least 8 characters" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  if (user.password && !user.needsPasswordSetup) {
    if (!currentPassword || user.password !== currentPassword) {
      res.status(401).json({ error: "Current password is incorrect" }); return;
    }
  }
  await db.update(usersTable).set({ password, needsPasswordSetup: false }).where(eq(usersTable.id, userId));
  res.json({ success: true, message: "Password updated successfully. You can now sign in with email + password." });
});

// DELETE /auth/account
router.delete("/auth/account", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { confirmation } = req.body;
  if (confirmation !== "DELETE_MY_ACCOUNT") {
    res.status(400).json({ error: "Type DELETE_MY_ACCOUNT to confirm" }); return;
  }
  await db.update(usersTable).set({ deletedAt: new Date(), sessionToken: null }).where(eq(usersTable.id, userId));
  res.json({ success: true, message: "Account permanently deleted." });
});

// POST /auth/2fa/setup
router.post("/auth/2fa/setup", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const secret = makeTotpSecret();
  await db.update(usersTable).set({ twoFactorSecret: secret }).where(eq(usersTable.id, userId));
  const [user] = await db.select({ email: usersTable.email }).from(usersTable).where(eq(usersTable.id, userId));
  res.json({
    secret,
    qrCodeUrl: `otpauth://totp/WizardryAI:${user?.email}?secret=${secret}&issuer=WizardryAI`,
    backupCodes: Array.from({ length: 8 }, () => Math.random().toString(36).slice(2, 10).toUpperCase()),
    hint: "Enter code 123456 to verify in demo mode",
  });
});

// POST /auth/2fa/verify
router.post("/auth/2fa/verify", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { otp } = req.body;
  if (!otp) { res.status(400).json({ error: "OTP required" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user?.twoFactorSecret) { res.status(400).json({ error: "2FA not set up yet" }); return; }
  // Demo: accept "123456" or any 6-digit code
  if (!/^\d{6}$/.test(otp)) { res.status(401).json({ error: "Invalid OTP — must be 6 digits. Use 123456 in demo mode." }); return; }
  await db.update(usersTable).set({ twoFactorEnabled: true }).where(eq(usersTable.id, userId));
  res.json({ success: true, message: "Two-factor authentication enabled successfully." });
});

// POST /auth/2fa/disable
router.post("/auth/2fa/disable", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  await db.update(usersTable).set({ twoFactorEnabled: false, twoFactorSecret: null }).where(eq(usersTable.id, userId));
  res.json({ success: true });
});

export default router;
