import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, subscriptionsTable, settingsTable, notificationsTable } from "@workspace/db";
import { getUserId } from "../lib/auth";

const router: IRouter = Router();

router.get("/users/me", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user || user.deletedAt) { res.status(404).json({ error: "User not found" }); return; }
  const { password: _p, twoFactorSecret: _t, sessionToken: _s, ...safe } = user;
  res.json(safe);
});

router.patch("/users/me", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { displayName, avatarUrl } = req.body;
  const [user] = await db.update(usersTable).set({ displayName, avatarUrl }).where(eq(usersTable.id, userId)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  const { password: _p, twoFactorSecret: _t, sessionToken: _s, ...safe } = user;
  res.json(safe);
});

router.post("/users/register", async (req, res): Promise<void> => {
  const { email, username, password, displayName } = req.body;
  if (!email || !username || !password) { res.status(400).json({ error: "Missing required fields" }); return; }
  if (password.length < 8) { res.status(400).json({ error: "Password must be at least 8 characters" }); return; }

  const [existingEmail] = await db.select({ id: usersTable.id, googleId: usersTable.googleId, authMethod: usersTable.authMethod }).from(usersTable).where(eq(usersTable.email, email));
  if (existingEmail) {
    if (existingEmail.googleId) {
      res.status(409).json({ error: "This email is linked to a Google account. Use Google Sign-In instead.", hint: "use_google" }); return;
    }
    res.status(409).json({ error: "Email already registered. Please sign in.", hint: "login" }); return;
  }

  const [existingUser] = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.username, username));
  if (existingUser) { res.status(409).json({ error: "Username already taken" }); return; }

  const [user] = await db.insert(usersTable).values({ email, username, password, displayName, authMethod: "email" }).returning();
  await db.insert(subscriptionsTable).values({ userId: user.id, planId: "free" });
  await db.insert(settingsTable).values({ userId: user.id });
  await db.insert(notificationsTable).values({
    userId: user.id, type: "greeting", priority: "medium",
    title: "Welcome to Wizardry AI",
    message: `Welcome, ${displayName || username}! Your account is ready. Start your first scan to detect deepfakes with enterprise-grade AI.`,
  });

  const { password: _p, twoFactorSecret: _t, sessionToken: _s, ...safe } = user;
  res.status(201).json({
    user: safe,
    userId: user.id,
    displayName: user.displayName || user.username,
    message: `Account created successfully! Welcome to Wizardry AI, ${displayName || username}!`,
  });
});

router.post("/users/login", async (req, res): Promise<void> => {
  const { email, password } = req.body;
  if (!email || !password) { res.status(400).json({ error: "Missing credentials" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (!user || user.deletedAt) {
    res.status(404).json({ error: "No account found with this email. Create one to get started.", hint: "register" }); return;
  }
  if (user.authMethod === "google" && !user.password) {
    res.status(401).json({ error: "This account was created with Google Sign-In. Use the Google button to log in.", hint: "use_google" }); return;
  }
  if (user.authMethod === "apple" && !user.password) {
    res.status(401).json({ error: "This account uses Apple Sign-In. Use the Apple button to log in.", hint: "use_apple" }); return;
  }
  if (user.password !== password) {
    res.status(401).json({ error: "Incorrect password. Please try again." }); return;
  }

  const { password: _p, twoFactorSecret: _t, sessionToken: _s, ...safe } = user;
  res.json({
    user: safe,
    userId: user.id,
    needsPasswordSetup: user.needsPasswordSetup,
    twoFactorEnabled: user.twoFactorEnabled,
    displayName: user.displayName || user.username,
    message: `Welcome back to Wizardry AI, ${user.displayName || user.username}!`,
  });
});

export default router;
