import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { setDefaultHeaders } from "@workspace/api-client-react";

// Read stored user ID from localStorage, fall back to demo user 1
const storedUserId = (() => {
  try {
    const v = localStorage.getItem("wizardry_user_id");
    const id = v ? parseInt(v, 10) : 1;
    return isNaN(id) ? 1 : id;
  } catch {
    return 1;
  }
})();

setDefaultHeaders({ "x-user-id": String(storedUserId) });

createRoot(document.getElementById("root")!).render(<App />);
