import { useLocation, Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NavSidebar from "@/components/NavSidebar";
import Scanner from "@/pages/Scanner";
import Dashboard from "@/pages/Dashboard";
import History from "@/pages/History";
import Notifications from "@/pages/Notifications";
import Settings from "@/pages/Settings";
import Profile from "@/pages/Profile";
import ApiKeys from "@/pages/ApiKeys";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import NotFound from "@/pages/not-found";
import { useGetMe, useGetCurrentSubscription } from "@workspace/api-client-react";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import PasswordUpdateModal from "@/components/PasswordUpdateModal";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } },
});

const PUBLIC_ROUTES = ["/login", "/register"];

function AppShell() {
  const [location] = useLocation();
  const isPublic = PUBLIC_ROUTES.some((r) => location.startsWith(r));
  const { data: user } = useGetMe();
  const { data: subscription } = useGetCurrentSubscription();
  const { needsPasswordSetup, setNeedsPasswordSetup, welcomeMessage, setWelcomeMessage } = useAuth();

  const handlePasswordSave = async (password: string) => {
    const res = await fetch("/api/auth/update-password", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-user-id": String(user?.id ?? 1) },
      body: JSON.stringify({ password }),
    });
    if (!res.ok) {
      const d = await res.json();
      throw { data: d };
    }
    setNeedsPasswordSetup(false);
  };

  if (isPublic) {
    return (
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
      </Switch>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <NavSidebar
        username={user?.displayName || user?.username || "Agent"}
        tier={subscription?.planId || user?.tier || "free"}
      />
      <main className="ml-60 min-h-screen p-6">
        <div className="max-w-6xl mx-auto">
          {/* Welcome back banner */}
          {welcomeMessage && (
            <div className="mb-4 flex items-center justify-between px-4 py-3 rounded-lg border border-emerald-500/25 bg-emerald-500/8 text-sm text-emerald-400 animate-fade-in-up">
              <span>🎉 {welcomeMessage}</span>
              <button onClick={() => setWelcomeMessage(null)} className="text-emerald-400/60 hover:text-emerald-400 ml-4">✕</button>
            </div>
          )}
          <Switch>
            <Route path="/" component={Scanner} />
            <Route path="/dashboard" component={Dashboard} />
            <Route path="/history" component={History} />
            <Route path="/notifications" component={Notifications} />
            <Route path="/settings" component={Settings} />
            <Route path="/profile" component={Profile} />
            <Route path="/api-keys" component={ApiKeys} />
            <Route path="/login" component={Login} />
            <Route path="/register" component={Register} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </main>

      {/* Password setup reminder modal */}
      {needsPasswordSetup && (
        <PasswordUpdateModal
          displayName={user?.displayName || user?.username}
          isNewUser={true}
          onClose={() => setNeedsPasswordSetup(false)}
          onSave={handlePasswordSave}
        />
      )}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <AppShell />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;
