import { useState, useCallback } from "react";
import { Zap, AlertCircle, CheckCircle2 } from "lucide-react";
import { useRegisterUser } from "@workspace/api-client-react";
import { useNavigate } from "@/hooks/useNavigate";
import { useAuth } from "@/contexts/AuthContext";

const GoogleIcon = () => (
  <svg className="w-4 h-4" viewBox="0 0 24 24">
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
  </svg>
);

const AppleIcon = () => (
  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
    <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.7 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.56-1.32 3.1-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
  </svg>
);

export default function Register() {
  const [form, setForm] = useState({ email: "", username: "", displayName: "", password: "" });
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [showAppleModal, setShowAppleModal] = useState(false);
  const [oauthEmail, setOauthEmail] = useState("");
  const [oauthName, setOauthName] = useState("");
  const [oauthLoading, setOauthLoading] = useState(false);
  const navigate = useNavigate();
  const register = useRegisterUser();
  const { login: authLogin, setWelcomeMessage, setNeedsPasswordSetup } = useAuth();

  const update = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((p) => ({ ...p, [key]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    try {
      const res = await register.mutateAsync({ data: form });
      const data = res as unknown as { userId?: number; message?: string; displayName?: string };
      if (data.userId) {
        authLogin(data.userId);
        setWelcomeMessage(data.message ?? `Welcome to Wizardry AI, ${data.displayName}!`);
      }
      setSuccessMsg(data.message ?? `Account created! Welcome to Wizardry AI, ${form.displayName || form.username}!`);
      setTimeout(() => navigate("/dashboard"), 1200);
    } catch (err: unknown) {
      const d = (err as { data?: { error?: string; hint?: string } })?.data;
      setError(d?.error ?? "Registration failed.");
      if (d?.hint === "use_google") {
        setTimeout(() => { setShowGoogleModal(true); setOauthEmail(form.email); }, 300);
      }
    }
  };

  const handleGoogleSignUp = useCallback(async () => {
    if (!oauthEmail.trim()) return;
    setOauthLoading(true);
    setError(null);
    const mockGoogleId = "google_" + oauthEmail.replace(/[^a-z0-9]/gi, "_").toLowerCase();
    try {
      const res = await fetch("/api/auth/google/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ googleId: mockGoogleId, email: oauthEmail, displayName: oauthName || oauthEmail.split("@")[0] }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error); return; }
      authLogin(data.userId);
      setWelcomeMessage(data.message);
      if (data.needsPasswordSetup) setNeedsPasswordSetup(true);
      setSuccessMsg(data.message);
      setShowGoogleModal(false);
      setTimeout(() => navigate("/dashboard"), 900);
    } catch {
      setError("Google sign-up failed.");
    } finally {
      setOauthLoading(false);
    }
  }, [oauthEmail, oauthName, authLogin, setWelcomeMessage, setNeedsPasswordSetup, navigate]);

  const handleAppleSignUp = useCallback(async () => {
    if (!oauthEmail.trim()) return;
    setOauthLoading(true);
    setError(null);
    const mockAppleId = "apple_" + oauthEmail.replace(/[^a-z0-9]/gi, "_").toLowerCase();
    try {
      const res = await fetch("/api/auth/apple/signin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ appleId: mockAppleId, email: oauthEmail, displayName: oauthName || oauthEmail.split("@")[0] }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error); return; }
      authLogin(data.userId);
      setWelcomeMessage(data.message);
      if (data.needsPasswordSetup) setNeedsPasswordSetup(true);
      setSuccessMsg(data.message);
      setShowAppleModal(false);
      setTimeout(() => navigate("/dashboard"), 900);
    } catch {
      setError("Apple sign-up failed.");
    } finally {
      setOauthLoading(false);
    }
  }, [oauthEmail, oauthName, authLogin, setWelcomeMessage, setNeedsPasswordSetup, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-8">
      <div className="w-full max-w-sm space-y-6 animate-fade-in-up">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="relative w-14 h-14 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center glow-violet">
              <Zap className="w-7 h-7 text-primary" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-foreground">Create Account</h1>
          <p className="text-sm text-muted-foreground mt-1">Join Wizardry AI — enterprise-grade deepfake detection</p>
        </div>

        {/* OAuth Buttons */}
        <div className="space-y-2">
          <button
            onClick={() => { setOauthEmail(""); setOauthName(""); setShowGoogleModal(true); }}
            className="w-full flex items-center justify-center gap-3 py-3 rounded-lg border border-border bg-white/5 hover:bg-white/10 transition-colors text-sm font-medium text-foreground"
          >
            <GoogleIcon />
            Sign up with Google
          </button>
          <button
            onClick={() => { setOauthEmail(""); setOauthName(""); setShowAppleModal(true); }}
            className="w-full flex items-center justify-center gap-3 py-3 rounded-lg border border-border bg-white/5 hover:bg-white/10 transition-colors text-sm font-medium text-foreground"
          >
            <AppleIcon />
            Sign up with Apple
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground">or sign up with email</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        {successMsg && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-sm text-emerald-400 animate-fade-in-up">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            {successMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {[
            { key: "displayName", label: "Display Name", type: "text", placeholder: "Full name" },
            { key: "username", label: "Username", type: "text", placeholder: "unique_handle" },
            { key: "email", label: "Email", type: "email", placeholder: "you@domain.com" },
            { key: "password", label: "Password", type: "password", placeholder: "Min 8 characters" },
          ].map(({ key, label, type, placeholder }) => (
            <div key={key} className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{label}</label>
              <input
                type={type}
                value={form[key as keyof typeof form]}
                onChange={update(key)}
                placeholder={placeholder}
                required
                className="w-full bg-input/40 border border-border rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary transition-colors"
              />
            </div>
          ))}

          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/25 text-xs text-destructive animate-fade-in-up">
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={register.isPending}
            className="w-full py-3 rounded-lg bg-primary text-white font-semibold text-sm hover:bg-primary/90 transition-colors glow-violet disabled:opacity-60"
          >
            {register.isPending ? (
              <span className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Creating account...
              </span>
            ) : "Create Account"}
          </button>
        </form>

        <p className="text-center text-xs text-muted-foreground">
          Already have an account?{" "}
          <button onClick={() => navigate("/login")} className="text-primary hover:text-primary/80 font-semibold transition-colors">Sign in</button>
        </p>
      </div>

      {/* Google Modal */}
      {showGoogleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-[#080c18] border border-border rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2"><GoogleIcon /><h3 className="text-sm font-bold text-foreground">Sign up with Google</h3></div>
              <button onClick={() => setShowGoogleModal(false)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <div className="space-y-3">
              <input type="email" value={oauthEmail} onChange={(e) => setOauthEmail(e.target.value)} placeholder="your@gmail.com" className="w-full bg-input/40 border border-border rounded-lg px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
              <input type="text" value={oauthName} onChange={(e) => setOauthName(e.target.value)} placeholder="Display name (optional)" className="w-full bg-input/40 border border-border rounded-lg px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            {error && <div className="text-xs text-destructive bg-destructive/10 border border-destructive/25 rounded-lg px-3 py-2">{error}</div>}
            <button onClick={handleGoogleSignUp} disabled={!oauthEmail.trim() || oauthLoading} className="w-full py-3 rounded-lg bg-primary text-white font-semibold text-sm disabled:opacity-50 hover:bg-primary/90 transition-colors">
              {oauthLoading ? "Creating account..." : "Continue with Google"}
            </button>
          </div>
        </div>
      )}

      {/* Apple Modal */}
      {showAppleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-[#080c18] border border-border rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2"><AppleIcon /><h3 className="text-sm font-bold text-foreground">Sign up with Apple</h3></div>
              <button onClick={() => setShowAppleModal(false)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <div className="space-y-3">
              <input type="email" value={oauthEmail} onChange={(e) => setOauthEmail(e.target.value)} placeholder="your@icloud.com" className="w-full bg-input/40 border border-border rounded-lg px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
              <input type="text" value={oauthName} onChange={(e) => setOauthName(e.target.value)} placeholder="Display name (optional)" className="w-full bg-input/40 border border-border rounded-lg px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
            </div>
            {error && <div className="text-xs text-destructive bg-destructive/10 border border-destructive/25 rounded-lg px-3 py-2">{error}</div>}
            <button onClick={handleAppleSignUp} disabled={!oauthEmail.trim() || oauthLoading} className="w-full py-3 rounded-lg bg-foreground text-background font-semibold text-sm disabled:opacity-50">
              {oauthLoading ? "Creating account..." : "Continue with Apple"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
