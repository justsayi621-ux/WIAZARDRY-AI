import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useListNotifications } from "@workspace/api-client-react";
import {
  LayoutDashboard, ScanLine, History, Bell, Settings, User, Key, LogOut, Zap, ChevronRight
} from "lucide-react";

const NAV_ITEMS = [
  { href: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/", icon: ScanLine, label: "Scanner" },
  { href: "/history", icon: History, label: "History" },
  { href: "/notifications", icon: Bell, label: "Notifications", badge: true },
  { href: "/settings", icon: Settings, label: "Settings" },
  { href: "/profile", icon: User, label: "Profile" },
  { href: "/api-keys", icon: Key, label: "API Keys" },
];

const TIER_COLORS: Record<string, string> = {
  free: "text-slate-400",
  basic: "text-blue-400",
  pro: "text-violet-400",
  advanced: "text-cyan-400",
  enterprise: "text-amber-400",
};

interface Props {
  username?: string;
  tier?: string;
}

export default function NavSidebar({ username = "User", tier = "free" }: Props) {
  const [location] = useLocation();
  const { data: notifications } = useListNotifications();
  const unread = notifications?.filter((n) => !n.read).length ?? 0;

  return (
    <aside className="fixed left-0 top-0 h-full w-60 flex flex-col z-40 bg-sidebar border-r border-sidebar-border">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
        <div className="relative w-8 h-8 flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary" />
          </div>
          <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-primary animate-pulse" />
        </div>
        <div>
          <span className="text-sm font-bold tracking-wide text-foreground">Wizardry</span>
          <span className="text-sm font-bold tracking-wide text-primary"> AI</span>
        </div>
      </div>

      {/* Nav Links */}
      <nav className="flex-1 py-4 px-3 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map(({ href, icon: Icon, label, badge }) => {
          const active = location === href || (href === "/" && location === "/");
          return (
            <Link key={href} href={href}>
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium cursor-pointer transition-all duration-150 group relative",
                  active
                    ? "bg-primary/15 text-primary border border-primary/25"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground border border-transparent"
                )}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1">{label}</span>
                {badge && unread > 0 && (
                  <span className="min-w-[18px] h-[18px] text-[10px] font-bold bg-destructive text-white rounded-full flex items-center justify-center px-1">
                    {unread > 9 ? "9+" : unread}
                  </span>
                )}
                {active && <ChevronRight className="w-3 h-3 opacity-50" />}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* User Area */}
      <div className="px-3 py-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-md bg-sidebar-accent/50">
          <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center flex-shrink-0">
            <span className="text-xs font-bold text-primary">{username[0]?.toUpperCase()}</span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-foreground truncate">{username}</div>
            <div className={cn("text-[11px] font-semibold uppercase tracking-wider", TIER_COLORS[tier] || "text-slate-400")}>
              {tier} tier
            </div>
          </div>
          <Link href="/profile">
            <LogOut className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground cursor-pointer transition-colors" />
          </Link>
        </div>
      </div>
    </aside>
  );
}
