import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react";
import { setDefaultHeaders } from "@workspace/api-client-react";

interface AuthContextValue {
  userId: number;
  login: (id: number) => void;
  logout: () => void;
  welcomeMessage: string | null;
  setWelcomeMessage: (msg: string | null) => void;
  needsPasswordSetup: boolean;
  setNeedsPasswordSetup: (v: boolean) => void;
}

const AuthContext = createContext<AuthContextValue>({
  userId: 1,
  login: () => {},
  logout: () => {},
  welcomeMessage: null,
  setWelcomeMessage: () => {},
  needsPasswordSetup: false,
  setNeedsPasswordSetup: () => {},
});

function getStoredUserId(): number {
  try {
    const v = localStorage.getItem("wizardry_user_id");
    const id = v ? parseInt(v, 10) : 1;
    return isNaN(id) ? 1 : id;
  } catch {
    return 1;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [userId, setUserId] = useState<number>(getStoredUserId);
  const [welcomeMessage, setWelcomeMessage] = useState<string | null>(null);
  const [needsPasswordSetup, setNeedsPasswordSetup] = useState(false);

  useEffect(() => {
    setDefaultHeaders({ "x-user-id": String(userId) });
  }, [userId]);

  const login = useCallback((id: number) => {
    localStorage.setItem("wizardry_user_id", String(id));
    setUserId(id);
    setDefaultHeaders({ "x-user-id": String(id) });
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("wizardry_user_id");
    localStorage.removeItem("wizardry_needs_pw_setup");
    setUserId(1);
    setDefaultHeaders({ "x-user-id": "1" });
  }, []);

  return (
    <AuthContext.Provider value={{ userId, login, logout, welcomeMessage, setWelcomeMessage, needsPasswordSetup, setNeedsPasswordSetup }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
