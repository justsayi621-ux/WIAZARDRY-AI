import { useGetMe, useGetTokenBalance, useGetCurrentSubscription } from "@workspace/api-client-react";

export const MOCK_USER_ID = 1;

export function useCurrentUser() {
  const { data: user, isLoading, error } = useGetMe({ query: { headers: { "x-user-id": String(MOCK_USER_ID) } } as never });
  return { user, isLoading, error };
}

export function useTokenWarning() {
  const { data: balance } = useGetTokenBalance({ query: { headers: { "x-user-id": String(MOCK_USER_ID) } } as never });
  return {
    balance,
    isNearLimit: balance?.isNearLimit ?? false,
    isExhausted: balance?.isExhausted ?? false,
    tokensRemaining: balance?.tokensRemaining ?? null,
  };
}
