// Wizardry AI — shared API utilities

export const USER_ID = 1; // simulated logged-in user

export function getHeaders(): Record<string, string> {
  return {
    "Content-Type": "application/json",
    "x-user-id": String(USER_ID),
  };
}

export const BASE_URL = import.meta.env.BASE_URL?.replace(/\/$/, "") || "";

export function apiUrl(path: string): string {
  return `/api${path}`;
}
