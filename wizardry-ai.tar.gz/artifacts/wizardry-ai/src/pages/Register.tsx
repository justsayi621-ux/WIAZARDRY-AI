import { useState } from "react";
import { Zap, AlertCircle } from "lucide-react";
import { useRegisterUser } from "@workspace/api-client-react";
import { useNavigate } from "@/hooks/useNavigate";

export default function Register() {
  const [form, setForm] = useState({ email: "", username: "", displayName: "", password: "" });
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const register = useRegisterUser();

  const update = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((p) => ({ ...p, [key]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await register.mutateAsync({ data: form });
      navigate("/dashboard");
    } catch (err: unknown) {
      const msg = (err as { data?: { error?: string } })?.data?.error ?? "Registration failed.";
      setError(msg);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-sm space-y-8 animate-fade-in-up">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <div className="relative w-14 h-14 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center glow-violet">
              <Zap className="w-7 h-7 text-primary" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-foreground">Create Account</h1>
          <p className="text-sm text-muted-foreground mt-1">Join Wizardry AI — enterprise-grade deepfake detection</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {[
            { key: "displayName", label: "Display Name", type: "text", placeholder: "Full name" },
            { key: "username", label: "Username", type: "text", placeholder: "unique_handle" },
            { key: "email", label: "Email", type: "email", placeholder: "you@domain.com" },
            { key: "password", label: "Password", type: "password", placeholder: "Min 8 characters" },
          ].map(({ key, label, type, placeholder }) => (
            <div key={key} className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{label}</label>
              <input
                type={type}
                value={form[key as keyof typeof form]}
                onChange={update(key)}
                placeholder={placeholder}
                required
                className="w-full bg-input/40 border border-border rounded-lg px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary transition-colors"
              />
            </div>
          ))}

          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/25 text-xs text-destructive animate-fade-in-up">
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={register.isPending}
            className="w-full py-3 rounded-lg bg-primary text-white font-semibold text-sm hover:bg-primary/90 transition-colors glow-violet disabled:opacity-60"
          >
            {register.isPending ? (
              <span className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Creating account...
              </span>
            ) : "Create Account"}
          </button>
        </form>

        <p className="text-center text-xs text-muted-foreground">
          Already have an account?{" "}
          <button onClick={() => navigate("/login")} className="text-primary hover:text-primary/80 font-semibold transition-colors">
            Sign in
          </button>
        </p>
      </div>
    </div>
  );
}
