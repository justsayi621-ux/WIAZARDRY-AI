import { useState, useRef, useCallback } from "react";
import { Upload, X, Play, ScanLine, AlertCircle, CheckCircle2, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatConfidence, parseJsonArray } from "@/lib/utils";
import { useCreateScan, useAnalyzeScan, useGetTokenBalance } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetRecentScansQueryKey, getGetScanStatsQueryKey, getGetDashboardStatsQueryKey, getGetTokenBalanceQueryKey } from "@workspace/api-client-react";
import VerdictBadge from "@/components/VerdictBadge";
import { MOCK_USER_ID } from "@/hooks/useCurrentUser";

const ENGINES = [
  { value: "gemini-2.5-flash", label: "Gemini 2.5 Flash (Ultra Fast)" },
  { value: "gemini-2.5-pro", label: "Gemini 2.5 Pro (Deep Analysis)" },
  { value: "zak-global", label: "ZAK Global Search Model (Surface + Deep Web Audit)" },
];

const SENSITIVITY_LEVELS = ["low", "medium", "high"] as const;

type ScanPhase = "idle" | "scanning" | "complete" | "failed";

interface AnalysisResult {
  verdict: string;
  confidenceScore: number | null;
  anomalies: string[];
  categories: string[];
  summary: string;
  tokensUsed: number;
  processingMs: number;
  modelUsed: string;
}

export default function Scanner() {
  const [file, setFile] = useState<File | null>(null);
  const [blobUrl, setBlobUrl] = useState<string | null>(null);
  const [urlInput, setUrlInput] = useState("");
  const [contextNote, setContextNote] = useState("");
  const [engine, setEngine] = useState(ENGINES[0].value);
  const [sensitivity, setSensitivity] = useState<"low" | "medium" | "high">("medium");
  const [phase, setPhase] = useState<ScanPhase>("idle");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const createScan = useCreateScan();
  const analyzeScan = useAnalyzeScan();

  const { data: tokenBalance } = useGetTokenBalance();
  const isGated = !file && !urlInput.trim();
  const isExhausted = tokenBalance?.isExhausted ?? false;

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (blobUrl) URL.revokeObjectURL(blobUrl);
    setFile(f);
    setBlobUrl(URL.createObjectURL(f));
    setResult(null);
    setErrorMsg(null);
    setPhase("idle");
  }, [blobUrl]);

  const handleRemoveFile = useCallback(() => {
    if (blobUrl) URL.revokeObjectURL(blobUrl);
    setFile(null);
    setBlobUrl(null);
    setPhase("idle");
    setResult(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }, [blobUrl]);

  const handleScan = useCallback(async () => {
    if (isGated || isExhausted) return;
    setPhase("scanning");
    setResult(null);
    setErrorMsg(null);
    try {
      const scan = await createScan.mutateAsync({
        data: {
          filename: file?.name ?? "url-media",
          mediaUrl: urlInput || undefined,
          mediaType: file?.type ?? "video/mp4",
          contextNote: contextNote || undefined,
          engineModel: engine,
          sensitivityLevel: sensitivity,
        },
      });
      const analysis = await analyzeScan.mutateAsync({
        data: {
          scanId: scan.id,
          engineModel: engine,
          contextNote: contextNote || undefined,
          sensitivityLevel: sensitivity,
        },
      });
      setResult({
        verdict: analysis.verdict,
        confidenceScore: analysis.confidenceScore ?? null,
        anomalies: Array.isArray(analysis.anomalies) ? analysis.anomalies : parseJsonArray(analysis.anomalies as unknown as string),
        categories: Array.isArray(analysis.categories) ? analysis.categories : parseJsonArray(analysis.categories as unknown as string),
        summary: analysis.summary ?? "",
        tokensUsed: analysis.tokensUsed ?? 3,
        processingMs: analysis.processingMs ?? 0,
        modelUsed: analysis.modelUsed ?? engine,
      });
      setPhase("complete");
      queryClient.invalidateQueries({ queryKey: getGetRecentScansQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetScanStatsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetDashboardStatsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetTokenBalanceQueryKey() });
    } catch (err: unknown) {
      setPhase("failed");
      const msg = (err as { data?: { error?: string } })?.data?.error ?? "Scan failed. Please try again.";
      setErrorMsg(msg);
    }
  }, [isGated, isExhausted, file, urlInput, contextNote, engine, sensitivity, createScan, analyzeScan, queryClient]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
          <ScanLine className="w-5 h-5 text-primary" />
          Forensic Scanner
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Upload media and run enterprise-grade AI deepfake detection.</p>
      </div>

      {/* Token exhaustion banner */}
      {isExhausted && (
        <div className="rounded-lg border border-destructive/40 bg-destructive/8 p-4 flex items-start gap-3 animate-fade-in-up">
          <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-destructive">Token limit reached</p>
            <p className="text-xs text-muted-foreground mt-1">You have used all your tokens for this period. Upgrade your plan to continue scanning.</p>
          </div>
        </div>
      )}

      {/* Near-limit warning */}
      {tokenBalance?.isNearLimit && !isExhausted && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/8 p-3 flex items-center gap-3 text-sm">
          <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span className="text-amber-300">Running low: <strong>{tokenBalance.tokensRemaining}</strong> tokens remaining.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Upload & Config */}
        <div className="space-y-5">
          {/* File Upload */}
          <div className="rounded-lg border border-border bg-card p-5 space-y-4">
            <h2 className="text-sm font-semibold text-foreground">Media Input</h2>

            {!blobUrl ? (
              <div>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full rounded-lg border-2 border-dashed border-border hover:border-primary/50 bg-muted/20 hover:bg-primary/5 transition-all p-8 flex flex-col items-center gap-3 text-muted-foreground hover:text-primary"
                >
                  <Upload className="w-8 h-8" />
                  <div className="text-center">
                    <p className="text-sm font-medium">Upload Video File</p>
                    <p className="text-xs mt-1">MP4, MOV, AVI, WebM supported</p>
                  </div>
                </button>
                <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={handleFileChange} />
                <div className="mt-3 flex items-center gap-2">
                  <div className="flex-1 h-px bg-border" />
                  <span className="text-xs text-muted-foreground">or</span>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <input
                  type="url"
                  placeholder="Paste video URL..."
                  value={urlInput}
                  onChange={(e) => { setUrlInput(e.target.value); setResult(null); setPhase("idle"); }}
                  className="mt-3 w-full bg-input/50 border border-border rounded-md px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
            ) : (
              <div className="space-y-3">
                <div className="relative rounded-lg overflow-hidden bg-black border border-border">
                  <video src={blobUrl} controls className="w-full max-h-48 object-contain" />
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="truncate max-w-[200px] mono">{file?.name}</span>
                  <button onClick={handleRemoveFile} className="flex items-center gap-1 text-destructive hover:text-destructive/80 transition-colors ml-2 flex-shrink-0">
                    <X className="w-3.5 h-3.5" />
                    Remove
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Context & Engine */}
          <div className="rounded-lg border border-border bg-card p-5 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Video Context / Description</label>
              <textarea
                rows={3}
                value={contextNote}
                onChange={(e) => setContextNote(e.target.value)}
                placeholder="Optional notes to guide the AI analysis..."
                className="w-full bg-input/40 border border-border rounded-md px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Select AI Engine Layer</label>
              <select
                value={engine}
                onChange={(e) => setEngine(e.target.value)}
                className="w-full bg-input/40 border border-border rounded-md px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary appearance-none cursor-pointer"
              >
                {ENGINES.map((e) => (
                  <option key={e.value} value={e.value}>{e.label}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Scan Sensitivity</label>
              <div className="flex gap-2">
                {SENSITIVITY_LEVELS.map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setSensitivity(lvl)}
                    className={cn(
                      "flex-1 py-2 rounded-md text-xs font-semibold capitalize border transition-all",
                      sensitivity === lvl
                        ? lvl === "high" ? "bg-destructive/15 border-destructive/40 text-destructive"
                          : lvl === "medium" ? "bg-amber-500/15 border-amber-500/30 text-amber-400"
                          : "bg-primary/15 border-primary/30 text-primary"
                        : "border-border text-muted-foreground hover:border-border/80"
                    )}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Scan Button & Results */}
        <div className="flex flex-col gap-5">
          {/* Radar Scan Button */}
          <div className="rounded-lg border border-border bg-card p-5 flex flex-col items-center gap-5">
            <h2 className="text-sm font-semibold text-foreground self-start">Initiate Scan</h2>
            <div className="relative flex items-center justify-center" style={{ width: 180, height: 180 }}>
              {/* Radar rings */}
              {phase === "scanning" && (
                <>
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="absolute rounded-full border border-primary/40 animate-radar-pulse"
                      style={{ width: 60 + i * 30, height: 60 + i * 30, animationDelay: `${(i - 1) * 0.5}s` }}
                    />
                  ))}
                  <div className="absolute w-full h-full rounded-full border border-primary/20 animate-radar-sweep"
                    style={{
                      background: "conic-gradient(from 0deg, transparent 0%, hsla(262,83%,58%,0.15) 30%, transparent 30%)",
                    }}
                  />
                </>
              )}

              {/* Main button */}
              <button
                onClick={handleScan}
                disabled={isGated || isExhausted || phase === "scanning"}
                className={cn(
                  "relative z-10 w-28 h-28 rounded-full border-2 font-bold text-sm tracking-wider transition-all duration-300 select-none",
                  isGated || isExhausted
                    ? "border-border/30 bg-muted/20 text-muted-foreground cursor-not-allowed"
                    : phase === "scanning"
                    ? "border-primary/60 bg-primary/10 text-primary cursor-wait animate-glow-pulse"
                    : phase === "complete"
                    ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/15"
                    : "border-primary/50 bg-primary/10 text-primary hover:bg-primary/15 hover:border-primary glow-violet active:scale-95"
                )}
              >
                {phase === "scanning" ? (
                  <span className="flex flex-col items-center gap-1">
                    <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    <span className="text-[10px]">SCANNING</span>
                  </span>
                ) : phase === "complete" ? (
                  <span className="flex flex-col items-center gap-1">
                    <CheckCircle2 className="w-5 h-5" />
                    <span className="text-[10px]">COMPLETE</span>
                  </span>
                ) : (
                  <span>SCAN NOW</span>
                )}
              </button>
            </div>

            {isGated && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Info className="w-3.5 h-3.5" />
                Upload a file or enter a URL to enable scanning
              </div>
            )}

            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>Cost per scan:</span>
              <span className="mono text-primary font-semibold">3 tokens</span>
            </div>
          </div>

          {/* Result */}
          {result && phase === "complete" && (
            <div className="rounded-lg border border-border bg-card p-5 space-y-4 animate-verdict-reveal">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Analysis Result</h3>
                <VerdictBadge verdict={result.verdict} size="md" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-muted/30 rounded-md p-3">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Confidence</div>
                  <div className="text-lg font-bold mono text-foreground mt-1">{formatConfidence(result.confidenceScore)}</div>
                </div>
                <div className="bg-muted/30 rounded-md p-3">
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Engine</div>
                  <div className="text-xs font-medium text-foreground mt-1 truncate">{result.modelUsed}</div>
                </div>
              </div>

              {result.summary && (
                <p className="text-xs text-muted-foreground leading-relaxed">{result.summary}</p>
              )}

              {result.anomalies.length > 0 && (
                <div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Anomalies Detected</div>
                  <div className="space-y-1">
                    {result.anomalies.map((a, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-amber-400 bg-amber-500/8 rounded px-2.5 py-1.5 border border-amber-500/20 animate-stagger-in" style={{ animationDelay: `${i * 0.08}s` }}>
                        <AlertCircle className="w-3 h-3 flex-shrink-0" />
                        {a}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {result.categories.length > 0 && (
                <div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Categories</div>
                  <div className="flex flex-wrap gap-1.5">
                    {result.categories.map((c, i) => (
                      <span key={i} className="text-[11px] px-2 py-0.5 rounded bg-destructive/15 text-destructive border border-destructive/25">{c}</span>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between text-[11px] text-muted-foreground border-t border-border pt-3">
                <span>Tokens used: <span className="text-primary mono font-semibold">{result.tokensUsed}</span></span>
                <span>Time: <span className="mono">{result.processingMs}ms</span></span>
              </div>
            </div>
          )}

          {phase === "failed" && errorMsg && (
            <div className="rounded-lg border border-destructive/40 bg-destructive/8 p-4 flex items-start gap-3 animate-fade-in-up">
              <AlertCircle className="w-4 h-4 text-destructive flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-destructive">Scan Failed</p>
                <p className="text-xs text-muted-foreground mt-1">{errorMsg}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
