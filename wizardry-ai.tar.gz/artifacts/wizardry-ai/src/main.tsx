import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { setDefaultHeaders } from "@workspace/api-client-react";

// Inject the demo user header for all API calls
setDefaultHeaders({ "x-user-id": "1" });

createRoot(document.getElementById("root")!).render(<App />);
