export const PLANS = [
  {
    id: "free",
    name: "Free Tier",
    price: 0,
    tokenLimit: 3,
    tokensPerRound: 3,
    features: ["Gemini 2.5 Flash only", "3 tokens total", "Basic scan results", "Community support"],
    recommended: false,
  },
  {
    id: "basic",
    name: "Basic",
    price: 9,
    tokenLimit: 250,
    tokensPerRound: 3,
    features: ["Gemini 2.5 Flash & Pro", "250 tokens/month (~83 scans)", "Detailed analysis reports", "Email support"],
    recommended: false,
  },
  {
    id: "pro",
    name: "Pro",
    price: 29,
    tokenLimit: 1000,
    tokensPerRound: 3,
    features: ["All AI engines", "1,000 tokens/month (~333 scans)", "Priority processing queue", "Anomaly breakdown", "Priority support"],
    recommended: true,
  },
  {
    id: "advanced",
    name: "Advanced",
    price: 59,
    tokenLimit: 3000,
    tokensPerRound: 3,
    features: ["All AI engines", "3,000 tokens/month (~1,000 scans)", "Advanced parameters access", "Batch scanning", "Dedicated support"],
    recommended: false,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 149,
    tokenLimit: null,
    tokensPerRound: 3,
    features: ["All AI engines", "Unlimited tokens", "API Developer Tab access", "Webhook integrations", "Custom API keys", "SLA guarantee", "White-glove onboarding"],
    recommended: false,
  },
];

export const TOKENS_PER_ROUND = 3;

export function getTokenLimit(planId: string): number | null {
  return PLANS.find((p) => p.id === planId)?.tokenLimit ?? 3;
}

export function getPlan(planId: string) {
  return PLANS.find((p) => p.id === planId);
}
