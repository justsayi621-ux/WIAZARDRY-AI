import { Router, type IRouter } from "express";
import { eq, and, desc, sql } from "drizzle-orm";
import { db, scansTable, usersTable, subscriptionsTable, notificationsTable } from "@workspace/db";
import { getUserId } from "../lib/auth";
import { TOKENS_PER_ROUND } from "../lib/plans";

const router: IRouter = Router();

router.get("/scans", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { filter, search, limit = "50", offset = "0" } = req.query as Record<string, string>;
  let query = db.select().from(scansTable).where(eq(scansTable.userId, userId)).$dynamic();
  const results = await db
    .select()
    .from(scansTable)
    .where(
      and(
        eq(scansTable.userId, userId),
        filter && filter !== "all" ? eq(scansTable.verdict, filter) : undefined,
        search ? sql`${scansTable.filename} ILIKE ${"%" + search + "%"}` : undefined,
      ),
    )
    .orderBy(desc(scansTable.createdAt))
    .limit(parseInt(limit))
    .offset(parseInt(offset));
  res.json(results);
});

router.post("/scans", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { filename, mediaUrl, mediaType, contextNote, engineModel, sensitivityLevel } = req.body;
  if (!engineModel) { res.status(400).json({ error: "engineModel is required" }); return; }
  const [scan] = await db.insert(scansTable).values({
    userId,
    filename,
    mediaUrl,
    mediaType,
    contextNote,
    engineModel,
    status: "pending",
    verdict: "unknown",
    sensitivityLevel: sensitivityLevel || "medium",
    tokensUsed: TOKENS_PER_ROUND,
  }).returning();
  res.status(201).json(scan);
});

router.get("/scans/stats", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const rows = await db.select().from(scansTable).where(eq(scansTable.userId, userId));
  const total = rows.length;
  const aiDetected = rows.filter((s) => s.verdict === "ai").length;
  const authentic = rows.filter((s) => s.verdict === "real").length;
  const uncertain = rows.filter((s) => s.verdict === "unknown").length;
  const mixed = rows.filter((s) => s.verdict === "mixed").length;
  const withScore = rows.filter((s) => s.confidenceScore != null);
  const avgConfidence = withScore.length > 0
    ? withScore.reduce((sum, s) => sum + (s.confidenceScore ?? 0), 0) / withScore.length
    : null;
  res.json({ total, aiDetected, authentic, uncertain, mixed, avgConfidence });
});

router.get("/scans/recent", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const scans = await db.select().from(scansTable).where(eq(scansTable.userId, userId)).orderBy(desc(scansTable.createdAt)).limit(5);
  res.json(scans);
});

router.post("/scans/analyze", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { scanId, engineModel, contextNote, sensitivityLevel } = req.body;
  if (!scanId) { res.status(400).json({ error: "scanId required" }); return; }
  const [scan] = await db.select().from(scansTable).where(and(eq(scansTable.id, scanId), eq(scansTable.userId, userId)));
  if (!scan) { res.status(404).json({ error: "Scan not found" }); return; }
  // Update scan to processing
  await db.update(scansTable).set({ status: "processing" }).where(eq(scansTable.id, scanId));
  // Simulate AI analysis with deterministic mock result
  const start = Date.now();
  await new Promise((r) => setTimeout(r, 800 + Math.random() * 400));
  const verdicts: Array<"ai" | "real" | "mixed" | "unknown"> = ["ai", "real", "mixed", "unknown"];
  const sensWeights: Record<string, number[]> = {
    low: [0.3, 0.5, 0.15, 0.05],
    medium: [0.35, 0.45, 0.15, 0.05],
    high: [0.4, 0.4, 0.15, 0.05],
  };
  const weights = sensWeights[sensitivityLevel || scan.sensitivityLevel || "medium"];
  const rand = Math.random();
  let cumulative = 0;
  let verdict: "ai" | "real" | "mixed" | "unknown" = "unknown";
  for (let i = 0; i < verdicts.length; i++) {
    cumulative += weights[i];
    if (rand < cumulative) { verdict = verdicts[i]; break; }
  }
  const confidenceScore = verdict === "unknown" ? 40 + Math.random() * 20 : 60 + Math.random() * 38;
  const processingMs = Date.now() - start;
  const anomalyOptions = ["Temporal inconsistency detected", "Facial landmark drift", "GAN artifacts in frame boundaries", "Audio-visual desync", "Compression signature mismatch", "Eye blink pattern anomaly"];
  const categoryOptions = ["Face Swap", "Voice Clone", "Full Body Synthesis", "Background Manipulation", "Temporal Artifacts"];
  const anomalies = verdict === "ai" || verdict === "mixed"
    ? JSON.stringify(anomalyOptions.slice(0, 2 + Math.floor(Math.random() * 3)))
    : JSON.stringify([]);
  const categories = verdict === "ai"
    ? JSON.stringify(categoryOptions.slice(0, 1 + Math.floor(Math.random() * 2)))
    : JSON.stringify([]);
  const [updated] = await db.update(scansTable).set({
    status: "complete",
    verdict,
    confidenceScore,
    processingMs,
    anomalies,
    categories,
    completedAt: new Date(),
    engineModel: engineModel || scan.engineModel,
    tokensUsed: TOKENS_PER_ROUND,
  }).where(eq(scansTable.id, scanId)).returning();
  // Update user counters
  const updateFields: Partial<typeof usersTable.$inferInsert> = { totalScans: sql`total_scans + 1` as any };
  if (verdict === "ai") updateFields.aiDetected = sql`ai_detected + 1` as any;
  else if (verdict === "real") updateFields.authentic = sql`authentic + 1` as any;
  else updateFields.uncertain = sql`uncertain + 1` as any;
  await db.update(usersTable).set(updateFields).where(eq(usersTable.id, userId));
  // Update token usage
  await db.update(subscriptionsTable).set({ tokensUsed: sql`tokens_used + ${TOKENS_PER_ROUND}` as any }).where(eq(subscriptionsTable.userId, userId));
  // Create scan complete notification
  const priorityAlert = confidenceScore > 85;
  await db.insert(notificationsTable).values({
    userId,
    type: "scan_complete",
    title: `Scan Complete: ${verdict.toUpperCase()} Detected`,
    message: `Analysis of "${scan.filename || "media"}" is complete. Verdict: ${verdict} with ${confidenceScore.toFixed(1)}% confidence.`,
    priority: priorityAlert ? "high" : "medium",
  });
  res.json({
    verdict: updated.verdict,
    confidenceScore: updated.confidenceScore,
    anomalies: JSON.parse(anomalies),
    categories: JSON.parse(categories),
    summary: `Analysis complete. ${verdict === "ai" ? "Synthetic AI media detected with high confidence." : verdict === "real" ? "Media appears authentic with no significant anomalies." : verdict === "mixed" ? "Mixed signals detected — partial manipulation possible." : "Inconclusive results. Consider re-scanning with higher sensitivity."}`,
    tokensUsed: TOKENS_PER_ROUND,
    processingMs,
    modelUsed: updated.engineModel,
  });
});

router.get("/scans/:id", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [scan] = await db.select().from(scansTable).where(and(eq(scansTable.id, id), eq(scansTable.userId, userId)));
  if (!scan) { res.status(404).json({ error: "Scan not found" }); return; }
  res.json(scan);
});

router.delete("/scans/:id", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [scan] = await db.delete(scansTable).where(and(eq(scansTable.id, id), eq(scansTable.userId, userId))).returning();
  if (!scan) { res.status(404).json({ error: "Scan not found" }); return; }
  res.sendStatus(204);
});

export default router;
