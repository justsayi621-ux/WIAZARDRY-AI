import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, subscriptionsTable, settingsTable, notificationsTable } from "@workspace/db";
import { getUserId } from "../lib/auth";

const router: IRouter = Router();

router.get("/users/me", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(user);
});

router.patch("/users/me", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return; }
  const { displayName, avatarUrl } = req.body;
  const [user] = await db.update(usersTable).set({ displayName, avatarUrl }).where(eq(usersTable.id, userId)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  res.json(user);
});

router.post("/users/register", async (req, res): Promise<void> => {
  const { email, username, password, displayName } = req.body;
  if (!email || !username || !password) { res.status(400).json({ error: "Missing required fields" }); return; }
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing.length > 0) { res.status(409).json({ error: "Email already registered" }); return; }
  const [user] = await db.insert(usersTable).values({ email, username, password, displayName }).returning();
  // Create default subscription, settings, and welcome notification
  await db.insert(subscriptionsTable).values({ userId: user.id, planId: "free" });
  await db.insert(settingsTable).values({ userId: user.id });
  await db.insert(notificationsTable).values({
    userId: user.id,
    type: "greeting",
    title: "Welcome to Wizardry AI",
    message: `Welcome, ${displayName || username}! Your account is ready. Start your first scan to detect deepfakes with enterprise-grade AI.`,
    priority: "medium",
  });
  res.status(201).json(user);
});

router.post("/users/login", async (req, res): Promise<void> => {
  const { email, password } = req.body;
  if (!email || !password) { res.status(400).json({ error: "Missing credentials" }); return; }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (!user || user.password !== password) { res.status(401).json({ error: "Invalid credentials" }); return; }
  res.json({ user, token: `mock_token_${user.id}` });
});

export default router;
