import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  inferenceMode: text("inference_mode").notNull().default("hybrid"),
  scanSensitivity: text("scan_sensitivity").notNull().default("medium"),
  dataUsageMode: text("data_usage_mode").notNull().default("normal"),
  autoDeleteDays: integer("auto_delete_days"),
  localOnlyMode: boolean("local_only_mode").notNull().default(false),
  pushNotifications: boolean("push_notifications").notNull().default(true),
  notificationBarResults: boolean("notification_bar_results").notNull().default(true),
  silentMode: boolean("silent_mode").notNull().default(false),
  priorityAlert: boolean("priority_alert").notNull().default(true),
  darkMode: boolean("dark_mode").notNull().default(true),
  language: text("language").notNull().default("en"),
  timezone: text("timezone").notNull().default("UTC"),
  twoFactorEnabled: boolean("two_factor_enabled").notNull().default(false),
  sessionTimeout: integer("session_timeout").notNull().default(30),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({ id: true, updatedAt: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;
